function optiinfo(message,varargin)
%Display an info message

fprintf([message '\n'],varargin{:});