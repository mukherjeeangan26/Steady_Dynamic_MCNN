% OPTI Toolbox
% Version 2.28 (R2017b) 04-Mar-2018
% Copyright (C) 2011-2018 Jonathan Currie (Inverse Problem Ltd)
% License: https://inverseproblem.co.nz/OPTI/index.php/DL/License
