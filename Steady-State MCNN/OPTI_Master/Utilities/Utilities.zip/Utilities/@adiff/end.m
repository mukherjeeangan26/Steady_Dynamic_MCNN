function n = end(ad,dim,n)
% END is the last index of an adiff object
n = length(ad.x);