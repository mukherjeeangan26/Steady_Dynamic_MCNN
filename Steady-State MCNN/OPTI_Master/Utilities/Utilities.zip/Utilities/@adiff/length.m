function n = length(ad)
% LENGTH for adiff objects

n = length(ad.x);